package com.supergreen.cooperate.bank.service.impl;

import com.supergreen.cooperate.bank.domain.entity.Kyc;
import com.supergreen.cooperate.bank.repository.MemberRepository;
import com.supergreen.cooperate.bank.service.IKycService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class KycServiceImpl implements IKycService {

    @Autowired
    private MemberRepository memberRepository;

    @Override
    public Kyc getMemberKyc(Long id) {
        return memberRepository.findByMemberId(id).getKycDetail();
    }
}
