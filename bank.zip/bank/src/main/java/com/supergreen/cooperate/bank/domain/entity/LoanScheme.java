package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import javax.persistence.*;
import java.math.BigDecimal;

@Data
@Entity
@Table(name = "loan_scheme")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EnableJpaAuditing
@EntityListeners(AuditingEntityListener.class)
public class LoanScheme {

    @Id
    @GeneratedValue(generator = "scheme_id")
    @GenericGenerator(name = "scheme_id", strategy = "com.supergreen.cooperate.bank.generator.SchemeGenerator")
    private String schemeId;

    @Column(name = "loan_name", nullable = false)
    private String loanName;

    @Column(name = "approved_amount", nullable = false)
    private BigDecimal approvedAmount;

    @Column(name = "interest_rate", nullable = false)
    private Float interestRate;

    @Column(name = "max_tenure")
    private String maxTenure;

}
