package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "official_detail")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OfficialDetail {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long officialDetailId;

    @Column(name = "post", nullable = false)
    private String post;

    @Column(name = "section", nullable = false)
    private String section;

    @Column(name = "personal_number", nullable = false)
    private String personalNumber;

    @Column(name = "ticket_number", nullable = false)
    private String ticketNumber;

    @Column(name = "gross_salary", nullable = false)
    private String grossSalary;

    @Column(name = "appointment_date", nullable = false)
    private Date appointmentDate;

    @OneToMany(
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    @JoinColumn(name = "officialDetail", nullable = false)
    private List<Introducer> introducer;

}
