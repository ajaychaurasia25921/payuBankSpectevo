package com.supergreen.cooperate.bank.domain;

public enum DebitCreditIndicator {
    Debit, Credit;
}
