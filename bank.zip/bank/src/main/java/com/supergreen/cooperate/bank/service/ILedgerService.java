package com.supergreen.cooperate.bank.service;

import com.supergreen.cooperate.bank.domain.request.LedgerFilter;
import com.supergreen.cooperate.bank.domain.response.LedgerResponse;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

public interface ILedgerService {
    LedgerResponse filterLedger(LedgerFilter ledgerFilter, Pageable pageable);
}
