package com.supergreen.cooperate.bank.web.rest;

import com.supergreen.cooperate.bank.domain.entity.Member;
import com.supergreen.cooperate.bank.domain.response.OnboardResponse;
import com.supergreen.cooperate.bank.service.IOnboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/member")
public class OnboardRest {

    @Autowired
    private IOnboardService onboardService;


    @PostMapping(value = "/onboard")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public OnboardResponse onboard(@RequestBody Member member) {
        var response = onboardService.onboard(member);
        return response;
    }

    @PutMapping(value = "/{member_id}/onboard", consumes = {
            MediaType.MULTIPART_FORM_DATA_VALUE
    })
    public ResponseEntity dataUpload(@PathVariable("member_id") Long id,
                                     @RequestParam("member_photo") MultipartFile memberPhoto,
                                     @RequestParam("member_signature") MultipartFile memberSignature,
                                     @RequestParam("member_id_card") MultipartFile memberIdCard,
                                     @RequestParam("member_address_proof") MultipartFile memberAddressProof,
                                     @RequestParam("member_service_proof") MultipartFile memberServiceProof,
                                     @RequestParam("aadhar_card") MultipartFile aadharCard,
                                     @RequestParam("pan_card") MultipartFile panCard) throws IOException {
       return onboardService.dataUpload(id, memberPhoto, memberSignature,
               memberIdCard, memberAddressProof,
               memberServiceProof, aadharCard, panCard);
    }

    @GetMapping(value = "/{member_id}")
    public Member getMember(@PathVariable("member_id") Long id) {
        return onboardService.getMember(id);
    }


}
