package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@Entity
@Table(name = "introducer")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Introducer {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long introducerId;

    @Column(name = "name")
    private String name;

    @Column(name = "personal_number")
    private String personalNumber;

    @Column(name = "ticket_number")
    private String ticketNumber;

    @Column(name = "section")
    private String section;

    @Column(name = "post")
    private String post;

    @Transient
    @ManyToOne
    private OfficialDetail officialDetail;

}
