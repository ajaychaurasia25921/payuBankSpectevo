package com.supergreen.cooperate.bank.domain.response;

import com.supergreen.cooperate.bank.domain.AccountType;
import com.supergreen.cooperate.bank.domain.StaffTypeEnum;
import com.supergreen.cooperate.bank.domain.entity.Transaction;
import lombok.Data;
import org.springframework.data.domain.Page;

@Data
public class LedgerResponse {

    private Long memberId;

    private String firstName;

    private String lastName;

    private byte[] memberPhoto;

    private byte[] signature;

    private StaffTypeEnum staffType;

    private Page<Transaction> transactions;

}
