package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.ActionEnum;
import com.supergreen.cooperate.bank.domain.Mode;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "member")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EnableJpaAuditing
@EntityListeners(AuditingEntityListener.class)
public class Member {

    @Id
    private Long memberId;

    @Column(name = "registration_id", unique = true, nullable = false)
    private String registrationId;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "personal_detail", nullable = false)
    private PersonalDetail personalDetail;

    @OneToMany(
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JoinColumn(name = "member", nullable = false)
    private List<Address> address;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "official_detail", nullable = false)
    private OfficialDetail officialDetail;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "kyc_detail", nullable = false)
    private Kyc kycDetail;

    @OneToMany(
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JoinColumn(name = "member")
    private List<Account> account;

    @OneToMany(
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JoinColumn(name = "member", nullable = false)
    private List<NominationDetail> nominationDetail;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "official_secretary_action")
    private ActionEnum officialSecretaryAction = ActionEnum.No_Action;

    @Column(name = "official_secretary_remark")
    private String officialSecretaryRemark;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "official_chairman_action")
    private ActionEnum officialChairmanAction = ActionEnum.No_Action;

    @Column(name = "official_chairman_remark")
    private String officialChairmanRemark;

    @Transient
    private BigDecimal openBalance;

    @Transient
    private Mode mode;

    @CreatedDate
    @Column(name = "created_on", updatable = false)
    private Date createdOn;

    @LastModifiedDate
    @Column(name = "modified_on")
    private Date modifiedOn;

    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "modified_by")
    private String modifiedBy;

    @Lob
    @Column(name = "member_photo")
    private byte[] memberPhoto;

    @Lob
    @Column(name = "member_signature")
    private byte[] memberSignature;

}
