package com.supergreen.cooperate.bank.domain;

public enum ActionEnum {
    No_Action, Approved, Decline, Query;
}
