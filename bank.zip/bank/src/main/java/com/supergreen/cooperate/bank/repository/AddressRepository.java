package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
