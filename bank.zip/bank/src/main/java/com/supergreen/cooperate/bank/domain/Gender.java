package com.supergreen.cooperate.bank.domain;

public enum Gender {
    Male,Female,Others;
}
