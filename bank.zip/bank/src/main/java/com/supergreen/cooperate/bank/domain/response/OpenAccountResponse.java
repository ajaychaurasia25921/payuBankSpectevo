package com.supergreen.cooperate.bank.domain.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OpenAccountResponse {

    private String smAccountId;

    private String tfAccountId;

}
