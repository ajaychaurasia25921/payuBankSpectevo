package com.supergreen.cooperate.bank.domain;

public enum AddressType {
    Permanent,Mailing;
}
