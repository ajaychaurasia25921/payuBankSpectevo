package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.Introducer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IntroducerRepository extends JpaRepository<Introducer, Long> {
}
