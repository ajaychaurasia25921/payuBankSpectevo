package com.supergreen.cooperate.bank.domain.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

@Data
public class LedgerFilter {

    @NotNull
    private String accountId;

    private Date fromDate = fromDateDataAssign();

    private Date toDate = new Date();

    private Date fromDateDataAssign(){
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, -7);
        cal.set(Calendar.AM, 1);
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

}
