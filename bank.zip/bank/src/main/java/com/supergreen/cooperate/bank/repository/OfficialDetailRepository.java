package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.OfficialDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OfficialDetailRepository extends JpaRepository<OfficialDetail, Long> {
}
