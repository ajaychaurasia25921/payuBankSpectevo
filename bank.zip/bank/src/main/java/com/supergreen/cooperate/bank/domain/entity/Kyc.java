package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.KycStatus;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "kyc")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Kyc {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long Id;

    @Column(name = "aadhaar_card", unique = true)
    private String aadhaarCard;

    @Column(name = "pan_card", unique = true)
    private String panCard;

    @Column(name = "is_aadhaar_verified")
    private Boolean isAadhaarVerified = Boolean.FALSE;

    @Column(name = "aadhaar_status")
    private KycStatus aadhaarStatus = KycStatus.In_Progress;

    @Column(name = "is_pan_verified")
    private Boolean isPanVerified = Boolean.FALSE;

    @Column(name = "pan_status")
    private KycStatus panStatus = KycStatus.In_Progress;

    @Lob
    @Column(name = "member_id_card")
    private byte[] memberIdCard;

    @Lob
    @Column(name = "member_address_proof")
    private byte[] memberAddressProof;

    @Lob
    @Column(name = "member_service_proof")
    private byte[] memberServiceProof;

    @Lob
    @Column(name = "aadhaar_card_image")
    private byte[] aadhaarCardImage;

    @Lob
    @Column(name = "pan_card_image")
    private byte[] panCardImage;

}
