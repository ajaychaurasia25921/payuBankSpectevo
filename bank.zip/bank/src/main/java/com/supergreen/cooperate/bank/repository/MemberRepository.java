package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.StaffTypeEnum;
import com.supergreen.cooperate.bank.domain.entity.Member;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MemberRepository extends JpaRepository<Member, Long> {

    Member findByMemberId(Long id);

    List<Member> findAllByPersonalDetailFirstName(String firstName);

    List<Member> findAllByPersonalDetailFirstNameAndPersonalDetailStaffType(String firstName, StaffTypeEnum typeEnum);

    List<Member> findAllByPersonalDetailLastName(String lastName);

    List<Member> findAllByPersonalDetailLastNameAndPersonalDetailStaffType(String lastName, StaffTypeEnum typeEnum);

    List<Member> findAllByPersonalDetailFirstNameAndPersonalDetailLastName(String firstName, String lastName);

    List<Member> findAllByPersonalDetailStaffType(StaffTypeEnum typeEnum);

    List<Member> findAllByPersonalDetailFirstNameAndPersonalDetailLastNameAndPersonalDetailStaffType(String firstName, String lastName, StaffTypeEnum typeEnum);

    Member findFirstByOrderByMemberIdDesc();
}