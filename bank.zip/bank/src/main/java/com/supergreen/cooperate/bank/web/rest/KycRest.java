package com.supergreen.cooperate.bank.web.rest;

import com.supergreen.cooperate.bank.domain.entity.Kyc;
import com.supergreen.cooperate.bank.service.IKycService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/kyc")
public class KycRest {

    @Autowired
    private IKycService kycService;

    @GetMapping(value = "/member/{member_id}")
    @ResponseStatus(HttpStatus.FOUND)
    public Kyc getKycMember(@PathVariable("member_id") Long id) {
        return kycService.getMemberKyc(id);
    }

}
