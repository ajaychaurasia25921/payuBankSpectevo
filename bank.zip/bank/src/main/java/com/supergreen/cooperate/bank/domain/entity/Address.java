package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.supergreen.cooperate.bank.domain.AddressType;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

@Data
@Entity
@Table(name = "address")
public class Address {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long addressId;

    @Column(name = "line1" , nullable = false)
    private String addressLine1;

    @Column(name = "line2")
    private String addressLine2;

    @Column(name = "post_or_city")
    private String postOrCity;

    @Column(name = "district")
    private String district;

    @Column(name = "state")
    private String state;

    @Column(name = "country")
    private String country;

    @Column(name = "pin_code")
    private String pinCode;

    @Column(name = "contact")
    private String contact;

    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private AddressType type;

}
