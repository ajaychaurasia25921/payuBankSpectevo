package com.supergreen.cooperate.bank.service;

import com.supergreen.cooperate.bank.domain.entity.Member;
import com.supergreen.cooperate.bank.domain.response.OnboardResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface IOnboardService {


    OnboardResponse onboard(Member member);

    ResponseEntity dataUpload(Long id, MultipartFile memberPhoto,
                              MultipartFile memberSignature, MultipartFile memberIdCard,
                              MultipartFile memberAddressProof, MultipartFile memberServiceProof,
                              MultipartFile aadharCard, MultipartFile panCard) throws IOException;

    Member getMember(Long id);

}
