package com.supergreen.cooperate.bank.domain;

public enum AccountType {
    Share_Money, Thrift_Fund, Loan;
}
