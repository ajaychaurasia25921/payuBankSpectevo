package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.NominationDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NominationDetailRepository extends JpaRepository<NominationDetail, Long> {
}
