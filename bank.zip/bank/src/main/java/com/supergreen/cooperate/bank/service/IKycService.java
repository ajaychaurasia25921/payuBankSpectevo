package com.supergreen.cooperate.bank.service;

import com.supergreen.cooperate.bank.domain.entity.Kyc;

public interface IKycService {
    Kyc getMemberKyc(Long id);
}
