package com.supergreen.cooperate.bank.web.rest;

import com.supergreen.cooperate.bank.domain.request.LedgerFilter;
import com.supergreen.cooperate.bank.domain.response.LedgerResponse;
import com.supergreen.cooperate.bank.service.ILedgerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/ledger")
public class LedgerRest {

    @Autowired
    private ILedgerService ledgerService;

    @PostMapping(value = "/filter")
    public LedgerResponse filterLedger(@RequestBody LedgerFilter ledgerFilter, Pageable pageable) {
        return ledgerService.filterLedger(ledgerFilter, pageable);
    }

}
