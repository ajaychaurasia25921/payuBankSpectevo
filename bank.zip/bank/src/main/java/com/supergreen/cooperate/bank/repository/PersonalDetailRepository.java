package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.PersonalDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PersonalDetailRepository extends JpaRepository<PersonalDetail, Long> {
}
