package com.supergreen.cooperate.bank.service.impl;

import com.supergreen.cooperate.bank.domain.DebitCreditIndicator;
import com.supergreen.cooperate.bank.domain.Mode;
import com.supergreen.cooperate.bank.domain.entity.Transaction;
import com.supergreen.cooperate.bank.repository.AccountRepository;
import com.supergreen.cooperate.bank.repository.TransactionRepository;
import com.supergreen.cooperate.bank.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
@Transactional
public class TransactionServiceImpl implements ITransactionService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Override
    public Transaction crTxn(String accountId, BigDecimal amount, Mode mode, String notes) {
        var account = accountRepository.findByAccountId(accountId);
        var txn = new Transaction();
        account.setAccountBalance(account.getAccountBalance().add(amount));
        txn.setAccount(account);
        txn.setAmount(amount);
        txn.setBalance(account.getAccountBalance().add(amount));
        txn.setIndicator(DebitCreditIndicator.Credit);
        txn.setAccountId(accountId);
        txn.setMode(mode);
        txn.setNotes(notes);
        return transactionRepository.save(txn);
    }

    @Override
    public Transaction drTxn(String accountId, BigDecimal amount, Mode mode, String notes) {
        var account = accountRepository.findByAccountId(accountId);
        var txn = new Transaction();
        account.setAccountBalance(account.getAccountBalance().subtract(amount));
        txn.setAccount(account);
        txn.setAmount(amount);
        txn.setBalance(account.getAccountBalance().subtract(amount));
        txn.setIndicator(DebitCreditIndicator.Debit);
        txn.setAccountId(accountId);
        txn.setMode(mode);
        txn.setNotes(notes==null ? "" : notes);
        return transactionRepository.save(txn);
    }
}
