package com.supergreen.cooperate.bank.domain.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.KycStatus;
import com.supergreen.cooperate.bank.domain.ActionEnum;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OnboardResponse {

    private String registrationId;

    private String memberId;

    private String smAccountId;

    private String tfAccountId;

    private boolean kycVerified;

    private KycStatus kycStatus;

    private ActionEnum officialSecretaryAction;

    private ActionEnum officialChairmanAction;

}
