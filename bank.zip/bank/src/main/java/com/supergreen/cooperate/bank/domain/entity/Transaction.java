package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.AccountType;
import com.supergreen.cooperate.bank.domain.DebitCreditIndicator;
import com.supergreen.cooperate.bank.domain.Mode;
import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@EnableJpaAuditing
@Table(name = "transaction")
@JsonInclude(JsonInclude.Include.NON_NULL)
@EntityListeners(AuditingEntityListener.class)
public class Transaction {

    @Id
    @GeneratedValue(generator = "txn_id")
    @GenericGenerator(name = "txn_id", strategy = "com.supergreen.cooperate.bank.generator.TransactionGenerator")
    private String transactionId;

    @Column(name = "amount", nullable = false)
    private BigDecimal amount;

    @Column(name = "balance", nullable = false)
    private BigDecimal balance;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "mode", nullable = false)
    private Mode mode;

    @Column(name = "debit_or_credit_indicator", nullable = false)
    private DebitCreditIndicator indicator;

    @Column(name = "notes")
    private String notes;

    @CreatedDate
    @Column(name = "created_on", updatable = false)
    private Date createdOn;

    @LastModifiedDate
    @Column(name = "modified_on")
    private Date modifiedOn;

    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "modified_by")
    private String modifiedBy;

    @Transient
    @ManyToOne
    private Account account;

    @JsonIgnore
    @Column(name = "account_id", nullable = false)
    private String accountId;

}
