package com.supergreen.cooperate.bank.domain.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.KycStatus;
import lombok.Data;


@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KycResponse {
    private KycStatus status;
}
