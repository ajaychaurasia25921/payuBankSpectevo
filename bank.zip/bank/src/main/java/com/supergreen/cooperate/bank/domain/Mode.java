package com.supergreen.cooperate.bank.domain;

public enum Mode {
    Cash, UPI, Bank_Transfer, Cheque;
}
