package com.supergreen.cooperate.bank.service.impl;

import com.supergreen.cooperate.bank.domain.AccountType;
import com.supergreen.cooperate.bank.domain.DebitCreditIndicator;
import com.supergreen.cooperate.bank.domain.Mode;
import com.supergreen.cooperate.bank.domain.entity.Account;
import com.supergreen.cooperate.bank.domain.entity.Member;
import com.supergreen.cooperate.bank.domain.entity.Transaction;
import com.supergreen.cooperate.bank.domain.response.OnboardAccount;
import com.supergreen.cooperate.bank.domain.response.OnboardResponse;
import com.supergreen.cooperate.bank.domain.response.OpenAccountResponse;
import com.supergreen.cooperate.bank.repository.MemberRepository;
import com.supergreen.cooperate.bank.repository.TransactionRepository;
import com.supergreen.cooperate.bank.service.IOnboardService;
import com.supergreen.cooperate.bank.service.ITransactionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.UUID;

@Slf4j
@Service
@Transactional(isolation = Isolation.READ_COMMITTED)
public class OnboardServiceImpl implements IOnboardService {

    private static final String REGISTRATION_PREFIX = "REG";

    private static final String REGISTRATION_POSTFIX = "T";

    private static final String SM = "sm_";

    private static final String TF = "tf_";

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private ITransactionService transactionService;

    @Override
    public OnboardResponse onboard(Member member) {
        member.setRegistrationId(generateRegId());
        member.setMemberId(getNextMemberId());
        var account= openAccount(member);
        memberRepository.save(member);
        var response = new OnboardResponse();
        response.setRegistrationId(member.getRegistrationId());
        response.setMemberId(String.valueOf(member.getMemberId()));
        response.setSmAccountId(account.getSmAccountId());
        response.setTfAccountId(account.getTfAccountId());
        response.setOfficialSecretaryAction(member.getOfficialSecretaryAction());
        response.setOfficialChairmanAction(member.getOfficialChairmanAction());
        return response;
    }

    private String generateRegId() {
        return REGISTRATION_PREFIX +
                UUID.randomUUID().toString().substring(0,8)
                + REGISTRATION_POSTFIX;
    }

    private Long getNextMemberId() {
        var lastData = memberRepository.findFirstByOrderByMemberIdDesc();
        return (lastData == null) ? 1001 : lastData.getMemberId() + 1;
    }

    private OpenAccountResponse openAccount(Member member){
        var accountList = new ArrayList<Account>();
        var smData = new Account();
        smData.setType(AccountType.Share_Money);
        smData.setBlock(Boolean.FALSE);
        smData.setAccountBalance(BigDecimal.ZERO);
        smData.setAccountId(SM+member.getMemberId());
        smData.setMember(member);
        accountList.add(smData);
        var tfData = new Account();
        tfData.setType(AccountType.Thrift_Fund);
        tfData.setBlock(Boolean.FALSE);
        tfData.setAccountBalance(member.getOpenBalance());
        tfData.setAccountId(TF+member.getMemberId());
        tfData.setMember(member);

        var transaction = new Transaction();
        transaction.setMode(member.getMode());
        transaction.setAmount(member.getOpenBalance());
        transaction.setBalance(member.getOpenBalance());
        transaction.setIndicator(DebitCreditIndicator.Credit);
        transaction.setAccountId(tfData.getAccountId());
        transaction.setNotes("Opening Balance");
        tfData.setTransaction(Collections.singletonList(transaction));

        accountList.add(tfData);
        member.setAccount(accountList);
        return new OpenAccountResponse(smData.getAccountId(), tfData.getAccountId());
    }

    @Override
    public ResponseEntity dataUpload(Long id, MultipartFile memberPhoto, MultipartFile memberSignature,
                                     MultipartFile memberIdCard, MultipartFile memberAddressProof,
                                     MultipartFile memberServiceProof, MultipartFile aadharCard,
                                     MultipartFile panCard) throws IOException {
        var member = memberRepository.findByMemberId(id);
        if(null == member) {
            return ResponseEntity.badRequest().build();
        }
        member.setMemberPhoto(memberPhoto.getBytes());
        member.setMemberSignature(memberSignature.getBytes());
        member.getKycDetail().setMemberIdCard(memberIdCard.getBytes());
        member.getKycDetail().setMemberAddressProof(memberAddressProof.getBytes());
        member.getKycDetail().setMemberServiceProof(memberServiceProof.getBytes());
        member.getKycDetail().setAadhaarCardImage(aadharCard.getBytes());
        member.getKycDetail().setPanCardImage(panCard.getBytes());
        memberRepository.save(member);
        return ResponseEntity.ok().build();
    }

    @Override
    public Member getMember(Long id) {
        return memberRepository.findByMemberId(id);
    }

}
