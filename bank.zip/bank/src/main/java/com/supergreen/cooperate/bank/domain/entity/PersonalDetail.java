package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.Gender;
import com.supergreen.cooperate.bank.domain.StaffTypeEnum;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.Date;

@Data
@Entity
@Table(name = "personal_detail")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PersonalDetail {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long personalDetailId;

    @Column(name = "first_name", nullable = false)
    private String firstName;

    @Column(name = "middle_name")
    private String middleName;

    @Column(name = "last_name", nullable = false)
    private String lastName;

    @Column(name = "date_of_birth", nullable = false)
    private Date dateOfBirth;

    @Column(name = "gender")
    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Column(name = "nationality", nullable = false)
    private String nationality;

    @Column(name = "category", nullable = false)
    private String category;

    @Column(name = "father_or_husband_name", nullable = false)
    private String fatherOrHusbandName;

    @Column(name = "contact_number", nullable = false)
    private String contactNumber;

    @Email
    @Column(name = "email", nullable = false, unique = true)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(name = "staff_type", nullable = false)
    private StaffTypeEnum staffType;

    @Column(name = "qualification")
    private String qualification;

}
