package com.supergreen.cooperate.bank.service.impl;

import com.supergreen.cooperate.bank.domain.request.LedgerFilter;
import com.supergreen.cooperate.bank.domain.response.LedgerResponse;
import com.supergreen.cooperate.bank.repository.AccountRepository;
import com.supergreen.cooperate.bank.repository.MemberRepository;
import com.supergreen.cooperate.bank.repository.TransactionRepository;
import com.supergreen.cooperate.bank.service.ILedgerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LedgerServiceImpl implements ILedgerService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Override
    public LedgerResponse filterLedger(LedgerFilter ledgerFilter, Pageable pageable) {
        var transactions = transactionRepository.findByCreatedOnBetweenAndAccountId(ledgerFilter.getFromDate(),
                ledgerFilter.getToDate(), ledgerFilter.getAccountId(), pageable);
        var response = new LedgerResponse();
        var member = memberRepository.findByMemberId(Long.valueOf(ledgerFilter.getAccountId().substring(3)));
        response.setMemberId(member.getMemberId());
        response.setFirstName(member.getPersonalDetail().getFirstName());
        response.setLastName(member.getPersonalDetail().getLastName());
        response.setMemberPhoto(member.getMemberPhoto());
        response.setSignature(member.getMemberSignature());
        response.setStaffType(member.getPersonalDetail().getStaffType());
        response.setTransactions(transactions);
        return response;
    }

}
