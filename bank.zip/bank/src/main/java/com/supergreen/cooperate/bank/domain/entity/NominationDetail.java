package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "nominationDetail")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NominationDetail {

    @Id
    @SequenceGenerator(name = "sequence", initialValue = 1001)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    private Long nominationId;

    @Column(name = "name")
    private String name;

    @Column(name = "address")
    private String address;

    @Column(name = "relation")
    private String relation;

    @Transient
    @ManyToOne
    private Member member;

}
