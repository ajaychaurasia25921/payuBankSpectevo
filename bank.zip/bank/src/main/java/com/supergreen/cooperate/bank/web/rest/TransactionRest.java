package com.supergreen.cooperate.bank.web.rest;

import com.supergreen.cooperate.bank.domain.entity.Transaction;
import com.supergreen.cooperate.bank.domain.request.LedgerFilter;
import com.supergreen.cooperate.bank.domain.request.TransactionRequest;
import com.supergreen.cooperate.bank.domain.response.LedgerResponse;
import com.supergreen.cooperate.bank.service.ILedgerService;
import com.supergreen.cooperate.bank.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/transaction")
public class TransactionRest {

    @Autowired
    private ITransactionService transactionService;

    @PostMapping(value = "/credit")
    public Transaction credit(@RequestBody TransactionRequest request) {
        return transactionService.crTxn(request.getAccountId(),
                request.getAmount(),
                request.getMode(),
                request.getNotes());
    }

    @PostMapping(value = "/debit")
    public Transaction debit(@RequestBody TransactionRequest request) {
        return transactionService.drTxn(request.getAccountId(),
                request.getAmount(),
                request.getMode(),
                request.getNotes());
    }

}
