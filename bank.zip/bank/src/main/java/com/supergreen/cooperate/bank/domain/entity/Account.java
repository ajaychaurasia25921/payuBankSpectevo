package com.supergreen.cooperate.bank.domain.entity;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.AccountType;
import lombok.Data;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Entity
@Table(name = "account")
@EnableJpaAuditing
@EntityListeners(AuditingEntityListener.class)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Account {

    @Id
    @Column(name = "account_id")
    private String accountId;

    @Enumerated(EnumType.ORDINAL)
    @Column(name = "account_type")
    private AccountType type;

    @Column(name = "account_balance")
    private BigDecimal accountBalance;

    @ManyToOne
    @JoinColumn(name = "loan_scheme")
    private LoanScheme loanScheme;

    @Column(name = "interest_amount")
    private BigDecimal interestAmount;

    @Column(name = "blocked")
    private Boolean block;

    @Column(name = "closed")
    private Boolean closed;

    @CreatedDate
    @Column(name = "created_on", updatable = false)
    private Date createdOn;

    @LastModifiedDate
    @Column(name = "modified_on")
    private Date modifiedOn;

    @CreatedBy
    @Column(name = "created_by", updatable = false)
    private String createdBy;

    @LastModifiedBy
    @Column(name = "modified_by")
    private String modifiedBy;

    @Transient
    @ManyToOne
    private Member member;

    @OneToMany(
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @JoinColumn(name = "account")
    private List<Transaction> transaction;

}
