package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.LoanScheme;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoanSchemeRepository extends JpaRepository<LoanScheme, String> {
}
