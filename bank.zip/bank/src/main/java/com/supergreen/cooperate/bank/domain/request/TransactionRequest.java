package com.supergreen.cooperate.bank.domain.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.supergreen.cooperate.bank.domain.Mode;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionRequest {

    private String accountId;

    private BigDecimal amount;

    private Mode mode;

    private String notes;

}
