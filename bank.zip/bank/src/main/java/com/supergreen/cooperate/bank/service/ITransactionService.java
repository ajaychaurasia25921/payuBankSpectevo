package com.supergreen.cooperate.bank.service;

import com.supergreen.cooperate.bank.domain.Mode;
import com.supergreen.cooperate.bank.domain.entity.Transaction;

import java.math.BigDecimal;

public interface ITransactionService {

    Transaction crTxn(String accountId, BigDecimal amount, Mode mode, String notes);

    Transaction drTxn(String accountId, BigDecimal amount, Mode mode, String notes);

}
