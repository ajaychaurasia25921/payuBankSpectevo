package com.supergreen.cooperate.bank.domain;

public enum KycStatus {
    In_Progress, Done, Decline;
}
