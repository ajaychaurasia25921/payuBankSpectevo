package com.supergreen.cooperate.bank.repository;

import com.supergreen.cooperate.bank.domain.entity.Transaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;

public interface TransactionRepository extends JpaRepository<Transaction, String> {
    Page<Transaction> findByCreatedOnBetweenAndAccountId(Date fromDate, Date toDate, String accountId, Pageable pageable);
}
